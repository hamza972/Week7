package com.example.week_7.data;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;

import com.example.week_7.model.Note;
import com.example.week_7.util.Util;

import java.util.ArrayList;
import java.util.List;

public class DatabaseHelper extends SQLiteOpenHelper {
    public DatabaseHelper(@Nullable Context context)
    {
        super(context, Util.DATABASE_NAME,null,Util.DATABASE_VERSION);
    }
    @Override
    public void onCreate(SQLiteDatabase db) {
        String Create_Note_Table = "CREATE TABLE " + Util.Table_Name + "(" + Util.Note_ID + " INTEGER PRIMARY KEY AUTOINCREMENT , " + Util.Note_Name + " TEXT , " + Util.Note_Content + " TEXT)";

        db.execSQL(Create_Note_Table);

    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {


        String Drop_Note_Table = "DROP TABLE IF EXISTS ";
        db.execSQL(Drop_Note_Table, new String[]{Util.Table_Name});


        onCreate(db);

    }

    public long InsertNote (Note note)
    {
        SQLiteDatabase database = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put(Util.Note_Name, note.getName());
        contentValues.put(Util.Note_Name,note.getCont());
        long NewRowID = database.insert(Util.Table_Name,null,contentValues);
        database.close();
        return  NewRowID;
    }

    public List<Note> FetchNotes()
    {
        SQLiteDatabase database = this.getReadableDatabase();
        List<Note> Note_List = new ArrayList<>();
        Cursor cursor = database.rawQuery("SELECT * FROM " + Util.Table_Name,null);

        if (cursor.moveToFirst())
        {
            while (!cursor.isAfterLast())
            {
                String Note_Name = cursor.getString(cursor.getColumnIndex(Util.Note_Name));
                String Note_Content = cursor.getString(cursor.getColumnIndex(Util.Note_Content));
                Note_List.add(new Note(Note_Name, Note_Content ));
                cursor.moveToNext();
            }
        }
        database.close();
        return Note_List;
    }

    public Note FetchNote(String Name, String Content)
    {
        SQLiteDatabase database = this.getReadableDatabase();
        Note note;

        Cursor cursor = database.query(Util.Table_Name, new String[]{Util.Note_ID}, Util.Note_Name + "=? and " + Util.Note_Content + "=?",
                new String[] {Name,Content},null,null,null);
        String Note_Name = cursor.getString(cursor.getColumnIndex(Util.Note_Content));
        String Note_Content = cursor.getString(cursor.getColumnIndex(Util.Note_Content));
        note = new Note(Note_Name,Note_Content);
        database.close();
        return note;
    }

    public  void Delete_Note(Note note)
    {
        SQLiteDatabase database = this.getWritableDatabase();
        database.delete(Util.Table_Name, Util.Note_Name + "=?", new String[]{String.valueOf(note.getName())});
    }

    public boolean Update_Note (Note note)
    {
        SQLiteDatabase database = this.getWritableDatabase();

        ContentValues contentValues = new ContentValues();

        contentValues.put(Util.Note_Name,note.getName());
        contentValues.put(Util.Note_Content,note.getCont());
        database.update(Util.Table_Name, contentValues, Util.Note_Name + "=?", new String[]{String.valueOf(note.getName())});
        database.close();
        return true;
    }



}
