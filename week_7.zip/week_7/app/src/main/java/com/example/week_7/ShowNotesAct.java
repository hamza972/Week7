package com.example.week_7;

import android.content.Intent;
import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.week_7.data.DatabaseHelper;
import com.example.week_7.model.Note;
import com.example.week_7.model.NoteAdapter;

import java.util.List;

public class ShowNotesAct extends AppCompatActivity implements NoteAdapter.OnRowClickListener {
    private RecyclerView Notes_Recycler;
    private  NoteAdapter Notes_Adapter;
    private List<Note> Notes_List;

    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.show_notes);

        DatabaseHelper database = new DatabaseHelper(this);
        Notes_List = database.FetchNotes();

        Notes_Recycler = findViewById(R.id.Recycler);
        Notes_Adapter = new NoteAdapter(Notes_List,ShowNotesAct.this.getApplicationContext(), this);
        Notes_Recycler.setAdapter(Notes_Adapter);
        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(this);
        Notes_Recycler.setLayoutManager(linearLayoutManager);
        linearLayoutManager.setOrientation(RecyclerView.VERTICAL);
    }

    @Override
    public void onItemClick(int position) {
        Intent intent = new Intent(ShowNotesAct.this,UpdateNoteAct.class);
        intent.putExtra("Current_Note_Name", Notes_List.get(position).getName());
        intent.putExtra("Current_Note_Content", Notes_List.get(position).getCont());
        startActivity(intent);
        finish();

    }
}
