package com.example.week_7.model;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.week_7.R;

import java.util.List;

public class NoteAdapter extends RecyclerView.Adapter<NoteAdapter.ViewHolder> {

    private List<com.example.week_7.model.Note> noteList;

    private Context context;
    private  OnRowClickListener listener;

    public NoteAdapter(List<Note> noteList,Context context,OnRowClickListener listener)
    {
        this.noteList = noteList;
        this.context = context;
        this.listener = listener;
    }

    public interface OnRowClickListener
    {
        void onItemClick(int position);
    }


    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View itView = LayoutInflater.from(this.context).inflate(R.layout.note, parent,false);
        return new ViewHolder(itView,listener);
    }


    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
            holder.TextView_Note.setText(noteList.get(position).getName());
    }

    @Override
    public int getItemCount() {
        return noteList.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener {
        public TextView TextView_Note;
        public OnRowClickListener listener;


        public ViewHolder(@NonNull View itemView, OnRowClickListener listener) {
            super(itemView);
            TextView_Note = (TextView)itemView.findViewById(R.id.textViewNote);
            this.listener = listener;

            itemView.setOnClickListener((View.OnClickListener) this);
        }

        @Override
        public void onClick(View v) {

            listener.onItemClick(getAdapterPosition());

        }
    }
}
