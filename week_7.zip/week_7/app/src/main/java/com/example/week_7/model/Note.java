package com.example.week_7.model;

public class Note {
    private int ID;
    private String Name, Cont;

    public  int getID()
    {
        return ID;
    }

    public String getName()
    {
        return  Name;
    }

    public  void SetName(String name)
    {
        this.Name=name;
    }

    public  String getCont()
    {
        return Cont;
    }

    public Note(String name, String cont) {
        Name = name;
        Cont = cont;
    }
}
