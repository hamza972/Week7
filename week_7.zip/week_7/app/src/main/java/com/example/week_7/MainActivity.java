package com.example.week_7;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    Button butt_Create;
    Button butt_Show;
    ImageView Img_View;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        butt_Create = (Button) findViewById(R.id.button_1);
        butt_Show = (Button) findViewById(R.id.button_2);
        Img_View = (ImageView) findViewById(R.id.imageView);
    }


    public  void onClickCreate(View v)
    {
        Intent intent = new Intent(MainActivity.this,CreateNoteAct.class);
        startActivity(intent);
    }

    public void onClickShow(View v){
        Intent intent = new Intent(MainActivity.this, ShowNotesAct.class);
        startActivity(intent);
    }
}