package com.example.week_7;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.example.week_7.data.DatabaseHelper;
import com.example.week_7.model.Note;

public class CreateNoteAct extends AppCompatActivity {
    DatabaseHelper database;
    Button Butt_Done;
    EditText EditText_Subject, EditText_Cont;

    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.act_create_note);
        database = new DatabaseHelper(this);

        Butt_Done = (Button) findViewById(R.id.Done);
        EditText_Subject = findViewById(R.id.Subject);
        EditText_Cont = findViewById(R.id.Note);
    }

    public  void onCLickDone(View v)
    {
        String Name = EditText_Subject.getText().toString();
        String Cont = EditText_Cont.getText().toString();

        long res = database.InsertNote(new Note(Name,Cont));
        if (res !=0){
            Toast.makeText(CreateNoteAct.this, "Complete", Toast.LENGTH_SHORT).show();
            finish();
        }
        else
        {
            Toast.makeText(CreateNoteAct.this, "Somthing Went Wrong" , Toast.LENGTH_SHORT).show();
        }
    }
}
