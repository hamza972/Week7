package com.example.week_7;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.example.week_7.data.DatabaseHelper;
import com.example.week_7.model.Note;

public class UpdateNoteAct extends AppCompatActivity {

    DatabaseHelper database;
    String Note_Name;
    String Note_Content;
    Note note;
    String Updated_Name;
    String Updated_Content;

    EditText Update_Name;
    EditText Update_Content;
    Button Button_Update;
    Button Button_Delete;

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.update_note);
        database = new DatabaseHelper(this);

        Update_Name = findViewById(R.id.updateName);
        Update_Content = findViewById(R.id.updateContent);
        Button_Update = (Button)findViewById(R.id.update);
        Button_Delete = (Button)findViewById(R.id.Delete);

        Note_Name = getIntent().getStringExtra("Current_Note_Name");
        Note_Content = getIntent().getStringExtra("Current_Note_Content");
        Toast.makeText(UpdateNoteAct.this,"Note_Name" + Note_Name, Toast.LENGTH_SHORT).show();
        note = new Note(Note_Name,Note_Content);

        Update_Name.setText(note.getName());
        Update_Content.setText(note.getCont());

    }

    public  void onClickUpdate(View v)
    {
        EditText Update_Name_Edit = findViewById(R.id.updateName);
        EditText Update_Content_Edit = findViewById(R.id.updateContent);
        Updated_Name = Update_Name_Edit.getText().toString();
        Updated_Content = Update_Content_Edit.getText().toString();
        Note Update_Note = new Note(Updated_Name,Updated_Content);

        boolean Done = database.Update_Note(Update_Note);

        if (Done == true)
        {
            Toast.makeText(UpdateNoteAct.this,"Complete", Toast.LENGTH_SHORT).show();
            finish();
        }
        else{
            Toast.makeText(UpdateNoteAct.this, "Something Went Wrong", Toast.LENGTH_SHORT).show();

        }



    }

    public  void onClickDelete(View v)
    {
        database.Delete_Note(note);
        finish();
    }


}
